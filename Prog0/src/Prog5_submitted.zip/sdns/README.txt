My TCP and UDP servers, through use of common functions and an abstract common parent class with dispatch, reduce duplicate protocol handling as much as possible.

The parent class (utils/ServerProtocol.java) with dispatch allows polymorphic behavior while still maintaining only one area that handles the protocols.