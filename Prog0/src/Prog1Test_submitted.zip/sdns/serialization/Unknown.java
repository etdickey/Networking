package sdns.serialization;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Represents an unknown type and provide deserialization
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.1
 */
public class Unknown extends ResourceRecord {

    /**
     * Always throws UnsupportedOperationException
     * @param out serialization sink
     */
    @Override
    public void encode(OutputStream out) throws UnsupportedOperationException { throw new UnsupportedOperationException("Cannot encode Unknown type"); }

    /**
     * Returns a byte array of the rdata for this object.  For internal use only.
     * @return the serialized version of this objects rdata
     */
    @Override
    protected ArrayList<Byte> serializeRData() throws UnsupportedOperationException { throw new UnsupportedOperationException("Cannot encode Unknown type"); }

    @Override
    public long getTypeValue() { return -1L; }

    /**
     * Returns a String representation
     * Unknown: name=<name> ttl=<ttl>
     *   For example
     *     Unknown: name=foo.com. ttl=500
     * @return a String representation
     */
    @Override
    public String toString() { return "Unknown: name=" + this.getName() + " ttl=" + this.getTTL(); }

    /**
     * Checks for equality
     * @param o the object to compare to
     * @return whether or not the objects are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Unknown that = (Unknown) o;
        return this.getTTL() == that.getTTL() &&
                Objects.equals(this.getName(), that.getName());//technically not needed because taken care of in super.equal
    }
    //Let parent implement hash code because there's no more unique variables here

    /**
     * Hashes the object
     * @return the hashed value
     */
    @Override
    public int hashCode() {
        return Objects.hash(this.getName(), this.getTTL());
    }
}
