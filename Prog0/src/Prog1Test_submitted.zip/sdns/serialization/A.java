package sdns.serialization;

import java.net.Inet4Address;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Represents an A RR (IPv4 address) and provides serialization/deserialization
 * @author Ethan Dickey
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.0
 */
public class A extends ResourceRecord {
    Inet4Address address;

    /**
     * Constructs A RR using given values
     * @param name RR name
     * @param ttl RR TTL
     * @param address IPv4 address
     * @throws ValidationException if validation fails (see specification), including null name or address
     */
    public A(String name, int ttl, Inet4Address address) throws ValidationException{ }

    /**
     * Set address
     * @param address new address
     * @return this RR with new address
     * @throws ValidationException if address is invalid (null)
     */
    public A setAddress(Inet4Address address) throws ValidationException { return this; }

    /**
     * Get address
     * @return address of A RR
     */
    public Inet4Address getAddress() { return this.address; }

    /**
     * Returns a String representation
     * A: name=<name> ttl=<ttl> address=<address>
     *
     * For example
     * A: name=foo.com. ttl=500 address=1.2.3.4
     * @return a string representation
     */
    @Override
    public String toString(){ return null; }

    /**
     * Return type value for specific RR
     *
     * @return type value
     */
    @Override
    public long getTypeValue() {
        return A_TYPE_VALUE;
    }

    /**
     * Returns a byte array of the rdata for this object.  For internal use only.
     *
     * @return the serialized version of this objects rdata
     */
    @Override
    protected ArrayList<Byte> serializeRData() {
        return null;
    }

    /**
     * Checks for equality
     * @param o the object to compare to
     * @return whether or not the objects are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        A that = (A) o;
        return address.equals(that.address);
    }

    /**
     * Hashes the object
     * @return the hashed value
     */
    @Override
    public int hashCode() { return Objects.hash(super.hashCode(), address); }
}
