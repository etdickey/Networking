package sdns.serialization;

/**
 * Represents generic portion of message and provides serialization/deserialization Note: This is just an API
 * containing the required classes, methods, parameters and associated types. Implementation details such as
 * additional methods, abstract, etc. are TBD by the developer.
 * @author Ethan Dickey
 *  Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.0
 */
public abstract class Message {
    private int id;

    /**
     * Deserializes message from byte source.
     * Note: When deserialing RRs, a well-formed RR with an unknown type is deserialized as an Unknown
     * @param message deserialization byte source
     * @return a specific message resulting from deserialization
     * @throws NullPointerException if message is null
     * @throws ValidationException if parse or validation problem (including too few bytes)
     */
    public static Message decode(byte[] message) throws NullPointerException, ValidationException { return null; }

    /**
     * Serialize message as byte array
     * @return serialized message
     */
    public byte[] encode(){ return null; }

    /**
     * Get message ID
     * @return message ID
     */
    public int getID() { return -1; }

    /**
     * Set ID of message
     * @param id new id of message
     * @return this message with new id
     * @throws ValidationException if new id invalid
     */
    public Message setID(int id) throws ValidationException { return this; }

    /**
     * Get query (domain name) of message
     * @return message query
     */
    public String getQuery() { return null; }

    /**
     * Set message query (domain name)
     * @param query in the form of a domain name
     * @return this message with new query
     * @throws ValidationException if new query invalid or null
     */
    public Message setQuery(String query) throws ValidationException { return this; }
}
