package sdns.serialization;

import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Objects;

/**
 * Represents a NS and provides serialization/deserialization
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.1
 */
public class NS extends ResourceRecord {
    private String nameServer;

    /**
     * Constructs NS using given values
     * @param name RR name
     * @param ttl RR TTL
     * @param nameServer name server
     * @throws ValidationException if validation fails (see specification), including null name or nameServer
     */
    public NS(String name, int ttl, String nameServer) throws ValidationException {
        this.setTTL(ttl);
        //require non null, domain name validation happens in each individual method
        try {
            this.setName(Objects.requireNonNull(name, "Name cannot be null"));
        } catch(NullPointerException n){
            throw new ValidationException(n.getMessage(), name);
        }
        try {
            this.setNameServer(Objects.requireNonNull(nameServer, "Name Server cannot be null"));
        } catch(NullPointerException n){
            throw new ValidationException(n.getMessage(), nameServer);
        }
    }

    /**
     * Get name server
     * @return name
     */
    public String getNameServer() { return this.nameServer; }

    /**
     * Set name server
     * @param nameServer new name server
     * @return this NS with new name server
     * @throws ValidationException if invalid name server, including null
     */
    public NS setNameServer(String nameServer) throws ValidationException {
        try {
            Objects.requireNonNull(nameServer, "Name Server cannot be null");
        } catch(NullPointerException n){
            throw new ValidationException(n.getMessage(), nameServer);
        }

        //require non null and validate domain name all in one!
        if(validateDomainName(nameServer)){
            this.nameServer = nameServer;
        } else {
            throw new ValidationException("Name Server did not pass domain name checks", nameServer);
        }

        return this;
    }

    /**
     * Returns a String representation
     * NS: name=<name> ttl=<ttl> nameserver=<nameserver>
     *   For example
     *     NS: name=foo.com. ttl=500 nameserver=ns.com
     * @return a String representation
     */
    @Override
    public String toString() { return "NS: name=" + this.getName() + " ttl=" + this.getTTL() + " nameserver=" + this.getNameServer(); }

    @Override
    public long getTypeValue() { return NS_TYPE_VALUE; }

    /**
     * Returns a byte array of the rdata for this object.  For internal use only.
     * @return the serialized version of this objects rdata
     */
    @Override
    protected ArrayList<Byte> serializeRData(){
        ArrayList<Byte> rdataBytes = new ArrayList<>();
        try {
            this.serializeDomainName(this.getNameServer(), rdataBytes);
        } catch (ValidationException e) {
            //Do nothing
//            throw new ValidationException("WARN WARN WARN: \"NAMESERVER\" FIELD DOES NOT CONTAIN A VALID DOMAIN NAME", this.getName());
        }

        return rdataBytes;
    }

    /**
     * Checks for equality
     * @param o the object to compare to
     * @return whether or not the objects are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        NS that = (NS) o;
        return nameServer.equals(that.nameServer);
    }

    /**
     * Hashes the object
     * @return the hashed value
     */
    @Override
    public int hashCode() { return Objects.hash(nameServer, super.hashCode()); }
}
