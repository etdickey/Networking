package sdns.serialization;

import java.io.IOException;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Objects;

/**
 * Represents a CName and provides serialization/deserialization
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.1
 */
public class CName extends ResourceRecord {
    private String canonicalName;

    /**
     * Constructs CName using given values
     * @param name RR name
     * @param ttl RR TTL
     * @param canonicalName Canonical name
     * @throws ValidationException if validation fails (see specification), including null name or canonical name
     */
    public CName(String name, int ttl, String canonicalName) throws ValidationException {
        this.setTTL(ttl);
        //require non null, domain name validation happens in each individual method
        try {
            this.setName(Objects.requireNonNull(name, "Name cannot be null"));
        } catch(NullPointerException n){
            throw new ValidationException(n.getMessage(), name);
        }
        try {
            this.setCanonicalName(Objects.requireNonNull(canonicalName, "Canonical Name cannot be null"));
        } catch(NullPointerException n){
            throw new ValidationException(n.getMessage(), canonicalName);
        }
    }

    /**
     * Get canonical name
     * @return name
     */
    public String getCanonicalName() { return this.canonicalName; }

    /**
     * Set canonical name
     * @param canonicalName new canonical name
     * @return this RR with new canonical name
     * @throws ValidationException if invalid canonical name, including null
     */
    public CName setCanonicalName(String canonicalName) throws ValidationException {
        try {
            Objects.requireNonNull(canonicalName, "Canonical Name cannot be null");
        } catch(NullPointerException n){
            throw new ValidationException(n.getMessage(), canonicalName);
        }

        //require non null and validate domain name all in one!
        if(validateDomainName(canonicalName)){
            this.canonicalName = canonicalName;
        } else {
            throw new ValidationException("Canonical Name did not pass domain name checks", canonicalName);
        }

        return this;
    }

    /**
     * Returns a String representation
     * CName: name=<name> ttl=<ttl> canonicalname=<canonicalname>
     *   For example
     *     CName: name=foo.com. ttl=500 canonicalname=ns.com
     *
     * @return String representation
     */
    @Override
    public String toString() { return "CName: name=" + this.getName() + " ttl=" + this.getTTL() + " canonicalname=" + this.getCanonicalName(); }

    /**
     * Return type value for specific RR
     * @return type value
     */
    @Override
    public long getTypeValue() { return CN_TYPE_VALUE; }

    /**
     * Returns a byte array of the rdata for this object.  For internal use only.
     * @return the serialized version of this objects rdata
     */
    @Override
    protected ArrayList<Byte> serializeRData(){
        ArrayList<Byte> rdataBytes = new ArrayList<>();
        try {
            this.serializeDomainName(this.getCanonicalName(), rdataBytes);
        } catch (ValidationException e) {
            //Do nothing
//            throw new ValidationException("WARN WARN WARN: \"CANONICALNAME\" FIELD DOES NOT CONTAIN A VALID DOMAIN NAME", this.getName());
        }

        return rdataBytes;
    }

    /**
     * Checks for equality
     * @param o the object to compare to
     * @return whether or not the objects are equal
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        CName that = (CName) o;
        return canonicalName.equals(that.canonicalName);
    }

    /**
     * Hashes the object
     * @return the hashed value
     */
    @Override
    public int hashCode() { return Objects.hash(canonicalName, super.hashCode()); }
}
