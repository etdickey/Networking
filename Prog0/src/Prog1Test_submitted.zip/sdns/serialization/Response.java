package sdns.serialization;

import java.util.List;

/**
 * Represents a SDNS response and provides serialization/deserialization
 * @author Ethan Dickey
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.1
 */
public class Response extends Message {
    private List<ResourceRecord> answerList = null;
    private List<ResourceRecord> nameServerList = null;
    private List<ResourceRecord> additionalList = null;
    private int responseCode;

    /**
     * Constructs SDNS response using given values
     * @param id query id
     * @param query query domain name
     * @throws ValidationException if validation fails (see specification), including null name or canonical name
     */
    public Response(int id, String query) throws ValidationException {}

    /**
     * Get response code
     * @return response code
     */
    public int getResponseCode() { return -1; }

    /**
     * Set new response code
     * @param rcode new response code
     * @return this Response with updated response code
     * @throws ValidationException if rcode is invalid
     */
    public Response setResponseCode(int rcode) throws ValidationException { return this; }

    /**
     * Get a list of RR answers
     * @return list of RRs
     */
    public List<ResourceRecord> getAnswerList() { return null; }

    /**
     * Add new answer to answer list (duplicates ignored)
     * @param answer new answer to add to answer list
     * @return this Response with new answer
     * @throws ValidationException if answer is invalid (null)
     */
    public Response addAnswer(ResourceRecord answer) throws ValidationException { return this; }

    /**
     * Get list of RR name servers
     * @return list of RRs
     */
    public List<ResourceRecord> getNameServerList() { return null; }

    /**
     * Add new name server to name server list (duplicates ignored)
     * @param nameServer new name server to add to name server list
     * @return this Response with new name server
     * @throws ValidationException if nameServer is invalid (null)
     */
    public Response addNameServer(ResourceRecord nameServer) throws ValidationException { return this; }

    /**
     * Get list of RR additionals
     * @return list of RRs
     */
    public List<ResourceRecord> getAdditionalList() { return null; }

    /**
     * Add new additional to additional list
     * @param additional new additional to add to additional list
     * @return this Response with new additional
     * @throws ValidationException if additinoal is invalid (null)
     */
    public Response addAdditional(ResourceRecord additional) throws ValidationException { return this; }

    /**
     * Returns a String representation
     * Response: id=<id> query=<query> answers=[<answer>,...,<answer>] nameservers=[<nameserver>,...,<nameserver>] additionals=[<additional>,...,<additional>]
     *
     * For example
     * Response: id=500 query=ns.com. answer=[a.com.,b.com.] nameservers=[ns1.com.] additionals=[]
     * @return a String representation
     */
    @Override
    public String toString(){ return null; }
}
