package sdns.serialization.test;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import sdns.serialization.*;

import java.io.ByteArrayInputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.Inet4Address;
import java.net.UnknownHostException;

import static org.junit.jupiter.api.Assertions.*;
/**
 * @author Ethan Dickey
 * @author Harrison Rogers
 */
class MessageTest {
    @Nested
    class DecodeMalformatted {
        @Test
        @DisplayName("Basic query test error short id")
        void queryDecodeMal1(){
            byte[] buff = { 0, //id
                    0, 0, //0 0000 [ignored bit]x4 000 0000
                    0, 1, //0x0001
                    0, 0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            assertThrows(ValidationException.class, () -> Message.decode(buff));
        }
        @Test
        @DisplayName("Basic query test errorshort flags")
        void queryDecodeMal2(){
            byte[] buff = { 0, 0,//id
                    0,  //0 0000 [ignored bit]x4 000 0000
                    0, 1, //0x0001
                    0, 0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            assertThrows(ValidationException.class, () -> Message.decode(buff));
        }
        @Test
        @DisplayName("Basic query test error bad 0x0001")
        void queryDecodeMal3(){
            byte[] buff = { 0, 0,//id
                    0, 0, //0 0000 [ignored bit]x4 000 0000
                    0, //0x0001
                    0, 0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            assertThrows(ValidationException.class, () -> Message.decode(buff));
        }
        @Test
        @DisplayName("Basic query test error bad 0x0001")
        void queryDecodeMal4(){
            byte[] buff = { 0, 0,//id
                    0, 0, //0 0000 [ignored bit]x4 000 0000
                    1, //0x0001
                    0, 0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            assertThrows(ValidationException.class, () -> Message.decode(buff));
        }
        @Test
        @DisplayName("Basic query test error short count")
        void queryDecodeMal5(){
            byte[] buff = { 0, 0,//id
                    0, 0, //0 0000 [ignored bit]x4 000 0000
                    0, 1, //0x0001
                    0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            assertThrows(ValidationException.class, () -> Message.decode(buff));
        }
        @Test
        @DisplayName("Basic query test error short query")
        void queryDecodeMal6(){
            byte[] buff = { 0, 0,//id
                    0, 0, //0 0000 [ignored bit]x4 000 0000
                    0, 1, //0x0001
                    0, 0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            assertThrows(ValidationException.class, () -> Message.decode(buff));
        }

        @Test
        @DisplayName("Null test")
        void inputStreamNull(){
            assertThrows(NullPointerException.class, () -> Message.decode(null));
        }
    }

    @Nested
    class DecodeValidationException {
        @Test
        @DisplayName("Basic query test invalid 0x0001")
        void queryDecodeMal6(){
            byte[] buff = { 0, 0,//id
                    0, 0, //0 0000 [ignored bit]x4 000 0000
                    0, 2, //0x0001
                    0, 0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            assertThrows(ValidationException.class, () -> Message.decode(buff));
        }
    }

    @Nested
    class DecodeValid {
        @Test
        @DisplayName("Basic query test")
        void basicQueryDecode(){
            byte[] buff = { 0, 0,//id
                    0, 0, //0 0000 [ignored bit]x4 000 0000
                    0, 1, //0x0001
                    0, 0, //ANCount
                    0, 0, //NSCount
                    0, 0, //ARCount
                    3, 'f', 'o', 'o', -64, 5,//query
                    0, -1,//0x00FF
                    0, 1  //0x0001
            };
            try {
                Message temp = Message.decode(buff);
                assert temp != null;
                assertAll(() -> assertEquals("foo.", temp.getQuery()),
                        () -> assertEquals(0, temp.getID())
                        );
            } catch (ValidationException e) {
                assert(false);
            }
        }

        @Test
        @DisplayName("Basic response test")
        void basicResponseDecode(){
            byte[] buff = { 0, 0,//id
                    -128, 0, //1 0000 [ignored bit]x4 000 0000
                    0, 1, //0x0001
                    0, 1, //ANCount
                    0, 1, //NSCount
                    0, 2, //ARCount
                    //answer
                    3, 'f', 'o', 'o', -64, 5,//CName
                    0, 5,
                    0, 1, //0x0001
                    0, 0, 0, 0,
                    0, 6,
                    3, 'f', 'o', 'o', -64, 5,

                    0,//A
                    0, 1,
                    0, 1,
                    0, 0, 0, 0,
                    0, 4,
                    -1, 0, -1, -119,

                    -64, 5,//NS
                    0, 2,
                    0, 1, //0x0001
                    0, 0, 0, 0,
                    0, 6,
                    3, 'f', 'o', 'o', -64, 5,

                    //authority
                    -64, 5,//NS
                    0, 2,
                    0, 1, //0x0001
                    0, 0, 0, 0,
                    0, 6,
                    3, 'f', 'o', 'o', -64, 5,

                    3, 'f', 'o', 'o', -64, 5,//NS
                    0, 2,
                    0, 1, //0x0001
                    0, 0, 0, 0,
                    0, 1,
                    0,

                    //additional
                    0,//A
                    0, 1,
                    0, 1,
                    0, 0, 0, 0,
                    0, 4,
                    0, 0, 0, 0,

                    3, 'f', 'o', 'o', -64, 5,//CName
                    0, 5,
                    0, 1, //0x0001
                    0, 0, 0, 0,
                    0, 6,
                    3, 'f', 'o', 'o', -64, 5

                    -64, 5,//NS
                    0, 2,
                    0, 1, //0x0001
                    0, 0, 0, 0,
                    0, 6,
                    3, 'f', 'o', 'o', -64, 5,
            };
            try {
                Message temp = Message.decode(buff);
                assert temp != null;

                NS ns1 = new NS(".", 0, "foo.");
                NS ns2 = new NS("foo.", 0, ".");
                CName cn1 = new CName("foo.", 0, "foo.");
                A a1 = new A(".", 0, (Inet4Address)Inet4Address.getByName("255.0.255.137"));

                assertAll(() -> assertEquals(Response.class, temp.getClass()),
                        () -> assertEquals("foo.", temp.getQuery()),
                        () -> assertEquals(0, temp.getID()),
                        () -> assertEquals(ns1, ((Response)temp).getNameServerList().get(0)),
                        () -> assertEquals(ns2, ((Response)temp).getNameServerList().get(1)),
                        () -> assertEquals(ns1, ((Response)temp).getAnswerList().get(2)),
                        () -> assertEquals(ns1, ((Response)temp).getAdditionalList().get(2)),

                        () -> assertEquals(cn1, ((Response)temp).getAnswerList().get(0)),
                        () -> assertEquals(cn1, ((Response)temp).getAdditionalList().get(1)),

                        () -> assertEquals(a1, ((Response)temp).getAnswerList().get(1)),
                        () -> assertEquals(a1, ((Response)temp).getAdditionalList().get(0))
                        );
            } catch (ValidationException | UnknownHostException e) {
                assert(false);
            }
        }
    }

    //test getter and setter for id
    @Nested
    class GetSetID {
        //ID test:: unsigned 16 bit integer
        @ParameterizedTest(name = "ID = {0}")
        @ValueSource(ints = {65536, -1, -2147418113})
        void setIdInvalid(int id){
            Message q;
            try {
                q = new Response(0, ".");
                assertThrows(ValidationException.class, () -> q.setID(id));
            } catch (ValidationException e) {
                assert(false);
            }
        }

        //Test valid IDs (16 bit unsigned int)
        @ParameterizedTest(name = "ID = {0}")
        @ValueSource(ints = {0, 1, 65535, 65280, 32768, 34952, 34824})
        void setIdValid(int id){
            Message q;
            try {
                q = new Response(0, ".");
                q.setID(id);
                assertEquals(id, q.getID());
            } catch (ValidationException e) {
                assert(false);
            }
        }
    }

    //test getter and setter for query
    @Nested
    class GetSetQuery {
        //Yay another domain name test
        @ParameterizedTest(name = "Query = {0}")
        @ValueSource(strings = {"", "asdf", "asdf.].", "asdf.Ƞ.", "asdf..", "www.baylor.edu/", "..", "asdf.asdf", "f0-9.c0m-.", "Ẵ.Ẓ.㛃.⭐.⭕.",
                "-a.f", "-.", "-",
                "a234567890123456789012345678901234567890123456789012345678901234.",//64
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a2345678901."//256
        })
        void setQueryInvalid(String query){
            Message q;
            try {
                q = new Response(0, ".");
                assertThrows(ValidationException.class, () -> q.setQuery(query));
            } catch (ValidationException e) {
                assert(false);
            }
        }

        //null test
        @Test
        @DisplayName("Null query")
        void setQueryNull(){
            Message q;
            try {
                q = new Response(0, ".");
                assertThrows(ValidationException.class, () -> q.setQuery(null));
            } catch (ValidationException e) {
                assert(false);
            }
        }

        //Valid queries (domain name tests)
        @ParameterizedTest(name = "Query = {0}")
        @ValueSource(strings = {"a23456789012345678901234567890123456789012345678901234567890123.",
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a234567890.",//255
                "foo.", "foo.com.", "f0-9.c0m.", "google.com.", "www.baylor.edu.", "f0.c-0.", ".", "f-0.", "f-0a."
        })
        void setQueryValid(String query){
            Message q;
            try {
                q = new Response(0, ".");
                q.setQuery(query);
                assertEquals(query, q.getQuery());
            } catch (ValidationException e) {
                assert(false);
            }
        }
    }
}