package sdns.serialization;

/**
 * Represents a SDNS query and provides serialization/deserialization
 * @author Ethan Dickey
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.0
 */
public class Query extends Message {
    /**
     * Constructs SDNS query using given values
     * @param id query id
     * @param query query domain name
     * @throws ValidationException if validation fails (see specification), invluding null name or canonical name
     */
    public Query(int id, String query) throws ValidationException {}

    /**
     * Returns a String representation
     * Query: id=<id> query=<query>
     *
     * For example
     * Query: id=500 query=ns.com.
     * @return a String representation
     */
    @Override
    public String toString() { return null; }
}
