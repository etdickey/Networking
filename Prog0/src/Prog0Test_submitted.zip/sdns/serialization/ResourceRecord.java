package sdns.serialization;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Represents generic SDNS RR and provides serialization/deserialization You may make concrete anything listed as
 * abstract in this interface. In other words, abstract is not part of the requirement
 * (while the class, method, and parameters are required).
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.0
 */
public abstract class ResourceRecord {
    private String name;
    private int ttl;

    /**
     * Validates a domain with the following constraints
     * @param domainName
     * @return
     */
    private boolean validateDomainName(String domainName){ return false; }

    /**
     * Deserializes message from input source
     * @param in deserialization input source
     * @return a specific RR resulting from deserialization
     * @throws ValidationException if parse or validation problem
     * @throws IOException if I/O problem (e.g., premature EoS)
     * @throws NullPointerException if in is null
     */
    public static ResourceRecord decode(InputStream in) throws ValidationException, IOException { return null; }

    /**
     * Serializes RR to given sink
     * @param out serialization sink
     * @throws IOException if I/O problem
     * @throws NullPointerException if out is null
     */
    public abstract void encode(OutputStream out) throws IOException;

    /**
     * Return type value for specific RR
     * @return type value
     */
    public abstract long getTypeValue();

    /**
     * Get name of RR
     * @return name
     */
    public String getName() { return null; }

    /**
     * Set name of RR
     * @param name new name of RR
     * @return this RR with new name
     * @throws ValidationException if new name invalid or null
     */
    public ResourceRecord setName(String name) throws ValidationException { return null; }

    /**
     * Get TTL of RR
     * @return TTL
     */
    public int getTTL(){ return -1; }

    /**
     * Set TTL of RR
     * @param ttl new TTL
     * @return this RR with new TTL
     * @throws ValidationException if new TTL invalid
     */
    public ResourceRecord setTTL(int ttl) throws ValidationException { return null; }
}
