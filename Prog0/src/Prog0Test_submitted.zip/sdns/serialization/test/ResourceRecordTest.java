package sdns.serialization.test;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import sdns.serialization.CName;
import sdns.serialization.NS;
import sdns.serialization.ResourceRecord;
import sdns.serialization.ValidationException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;

import static org.junit.jupiter.api.Assertions.*;

//Note: rerun all tests with different character encodings (UTF-32, UTF-16, etc) at runtime
/**
 * @author Ethan
 * @author Harrison
 */
class ResourceRecordTest {
    //Case insensitive string comparison

    //Test invalid input stream
    //  Too short in any field
    //  Too long in any field
    //Name:
    //  Each label must start with a letter, end with a letter or digit, and have as interior characters only letters
    //    (A-Z and a-z), digits (0-9), and hypen (-).
    //  A name with a single, empty label (".") is acceptable
    //
    //Test each field
    //  input too long, too short, null, invalid characters
    //  case insensitivity
    @Nested
    class DecodeValidationErrorInvalid {
        /*
        Valid data:
        byte[] buff = { 5, -64, 111, 111, 102, 3,//"foo."
                        2, 0,
                        1, 0,
                        0, 0, 0, 0,
                        6,
                        5, -64, 111, 111, 102, 3};//"foo."
         */
        @Test
        @DisplayName("Bad length name long")
        void decodeValidationError1(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', 'o', -64, 5,
                            0, 2,
                            0, 1,
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }
        @Test
        @DisplayName("Bad length name short")
        void decodeValidationError2(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'o', 'o', -64, 5,
                            0, 2,
                            0, 1,
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }
        @ParameterizedTest(name = "Bad name incorrect ending")
        @ValueSource(bytes = {64, -128, 0, 1, 96, 12, -96, -84})
        void decodeValidationError(byte badEnding){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', badEnding, 5,
                            0, 2,
                            0, 1,
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("Bad 0x0001")
        void decodeValidationError3(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0,
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }
        @Test
        @DisplayName("Bad 0x0001")
        void decodeValidationError4(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 1, 1,
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }
        @Test
        @DisplayName("Bad 0x0001")
        void decodeValidationError5(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 2,
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("Null input stream")
        void decodeNullInput(){
            assertThrows(NullPointerException.class, () -> ResourceRecord.decode(null));
        }

        @Test
        @DisplayName("No RDLength")
        void decodeValidationErrorNoRDLength(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 1,
                            0, 0, 0, 0,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("No Name")
        void decodeValidationErrorNoName(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = {
                            0, 2,
                            0, 1,
                            0, 0, 0, 0,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("Half Name")
        void decodeValidationErrorHalfName(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o',
                            0, 2,
                            0, 1,
                            0, 0, 0, 0,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("No type")
        void decodeValidationErrorNoType(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 1,
                            0, 0, 0, 0,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("No 0x0001")
        void decodeValidationErrorNo0x0001(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 0, 0, 0,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("No TTL")
        void decodeValidationErrorNoTTL(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 1,
                            0, 0, 0, 0,
                            3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @Test
        @DisplayName("No RData")
        void decodeValidationErrorNoRData(){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 1,
                            0, 0, 0, 0};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }
    }

    @Nested
    class DecodeValidationError {
        /*
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
        Valid data:
        byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 1, //0x0001
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};//"foo."
         */
        @ParameterizedTest(name = "Valid name = {0}")
        @ValueSource(strings = {"", "asdf", "asdf.].", "asdf.Ƞ.", "asdf..", "www.baylor.edu/", "..", "asdf.asdf", "f0-9.c0m-.", "Ẵ.Ẓ.㛃.⭐.⭕.",
                "-a.f", "-.", "-",
                "a234567890123456789012345678901234567890123456789012345678901234.",//64
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a2345678901."//256
        })
        void decodeName(String name){
            /*
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            Valid data:
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                                0, 2,
                                0, 1, //0x0001
                                0, 0, 0, 0,
                                6,
                                3, 'f', 'o', 'o', -64, 5};//"foo."
             */
            ArrayList<Byte> b = new ArrayList<>();
            serialize(name, b);

            //insert rest of bytes here
            Collections.addAll(b, (byte)0,
                    (byte)0, (byte)2,
                    (byte)0, (byte)1,
                    (byte)0, (byte)0, (byte)0, (byte)0,
                    (byte)6,
                    (byte)1, (byte)'o', (byte)0);

            byte[] buff = new byte[b.size()];
            for(int i=0;i<b.size();i++){
                buff[i] = b.get(i);
            }

            ByteArrayInputStream bstream = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(bstream));
        }

        @ParameterizedTest(name = "Valid name = {0}")
        @ValueSource(strings = {"", "asdf", "asdf.].", "asdf.Ƞ.", "asdf..", "www.baylor.edu/", "..", "asdf.asdf", "f0-9.c0m-.", "Ẵ.Ẓ.㛃.⭐.⭕.",
                "-a.f", "-.", "-",
                "a234567890123456789012345678901234567890123456789012345678901234.",//64
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a2345678901."//256
        })
        void decodeRDataInvalid(String name){
            /*
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            Valid data:
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                                0, 2,
                                0, 1, //0x0001
                                0, 0, 0, 0,
                                6,
                                3, 'f', 'o', 'o', -64, 5};//"foo."
             */
            ArrayList<Byte> b = new ArrayList<>();
            ArrayList<Byte> a = new ArrayList<>();

            //insert rest of bytes here
            Collections.addAll(a, (byte)1, (byte)'o', (byte)0,
                    (byte)0, (byte)2,
                    (byte)0, (byte)1,
                    (byte)0, (byte)0, (byte)0, (byte)0);

            serialize(name, b);

            a.add((byte)b.size());
            a.addAll(b);
            a.add((byte)0);

            byte[] buff = new byte[a.size()];
            for(int i=0;i<a.size();i++){
                buff[i] = a.get(i);
            }

            ByteArrayInputStream bstream = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(bstream));
        }

        @ParameterizedTest(name = "Bad label field: {0}")
        @ValueSource(bytes = {5, 3, -3, 0})
        void decodeValidationErrorLabel(byte n){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { n, 'f', 'o', 'o', 'o', -64, 5,
                    0, 2,
                    0, 1,
                    0, 0, 0, 0,
                    6,
                    3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        @ParameterizedTest(name = "Bad label field: {0}")
        @ValueSource(bytes = {7, 3, -3, 0, 127, -128})
        void decodeValidationErrorRDLength(byte n){
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            byte[] buff = { n, 'f', 'o', 'o', 'o', -64, 5,
                    0, 2,
                    0, 1,
                    0, 0, 0, 0,
                    6,
                    3, 'f', 'o', 'o', -64, 5};
            ByteArrayInputStream b = new ByteArrayInputStream(buff);
            assertThrows(ValidationException.class, () -> ResourceRecord.decode(b));
        }

        private void serialize(String name, ArrayList<Byte> b) {
            for(int i=0;i<name.length();i++){
                if((name.charAt(i) == '.' && i != name.length()-1) || i == 0){
                    byte len = 0;
                    //find how long next segment is
                    for(int j=i+1;j<name.length();j++){
                        if(name.charAt(j) == '.'){
                            len = (byte)(j-i-1);
                            break;
                        }
                    }
                    if(i == 0 && name.length() != 1){
                        len++;
                    }
                    b.add(len);
                } else {
                    b.add((byte) name.charAt(i));
                }
            }
        }
    }

    @Nested
    class DecodeValid {
        @ParameterizedTest(name = "Valid name = {0}")
        @ValueSource(strings = {"a23456789012345678901234567890123456789012345678901234567890123.",//63
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a234567890.",//255
                "foo.", "foo.com.", "f0-9.c0m.", "google.com.", "www.baylor.edu.", "f0.c-0.", ".", "f-0.", "f-0a."})
        void decodeName(String name){
            /*
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            Valid data:
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                                0, 2,
                                0, 1, //0x0001
                                0, 0, 0, 0,
                                6,
                                3, 'f', 'o', 'o', -64, 5};//"foo."
             */
            ArrayList<Byte> b = new ArrayList<>();
            serialize(name, b);

            //insert rest of bytes here
            Collections.addAll(b, (byte)0,
                    (byte)0, (byte)2,
                    (byte)0, (byte)1,
                    (byte)0, (byte)0, (byte)0, (byte)0,
                    (byte)6,
                    (byte)1, (byte)'o', (byte)0);

            byte[] buff = new byte[b.size()];
            for(int i=0;i<b.size();i++){
                buff[i] = b.get(i);
            }

            ByteArrayInputStream bstream = new ByteArrayInputStream(buff);
            ResourceRecord temp = null;
            try {
                temp = ResourceRecord.decode(bstream);
                assert temp != null;
                assertEquals(temp.getName(), name);
            } catch (ValidationException | IOException e) {
                assert(false);
                e.printStackTrace();
            }
        }


        @ParameterizedTest(name = "Valid name = {0}")
        @ValueSource(strings = {"a23456789012345678901234567890123456789012345678901234567890123.",//63
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a234567890.",//255
                "foo.", "foo.com.", "f0-9.c0m.", "google.com.", "www.baylor.edu.", "f0.c-0.", ".", "f-0.", "f-0a."})
        void decodeRDataNS(String name){
            /*
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            Valid data:
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                                0, 2,
                                0, 1, //0x0001
                                0, 0, 0, 0,
                                6,
                                3, 'f', 'o', 'o', -64, 5};//"foo."
             */
            ArrayList<Byte> b = new ArrayList<>();
            ArrayList<Byte> a = new ArrayList<>();

            //insert rest of bytes here
            Collections.addAll(a, (byte)1, (byte)'o', (byte)0,
                    (byte)0, (byte)2,
                    (byte)0, (byte)1,
                    (byte)0, (byte)0, (byte)0, (byte)0);

            serialize(name, b);

            a.add((byte)b.size());
            a.addAll(b);
            a.add((byte)0);

            byte[] buff = new byte[a.size()];
            for(int i=0;i<a.size();i++){
                buff[i] = a.get(i);
            }

            ByteArrayInputStream bstream = new ByteArrayInputStream(buff);
            ResourceRecord temp = null;
            try {
                temp = ResourceRecord.decode(bstream);
                assert(temp != null);
                assertEquals(((NS)temp).getNameServer(), name);
            } catch (ValidationException | IOException e) {
                assert(false);
                e.printStackTrace();
            }
        }

        @ParameterizedTest(name = "Valid name = {0}")
        @ValueSource(strings = {"a23456789012345678901234567890123456789012345678901234567890123.",//63
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a234567890.",//255
                "foo.", "foo.com.", "f0-9.c0m.", "google.com.", "www.baylor.edu.", "f0.c-0.", ".", "f-0.", "f-0a."})
        void decodeRDataCName(String name){
            /*
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            Valid data:
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                                0, 2,
                                0, 1, //0x0001
                                0, 0, 0, 0,
                                6,
                                3, 'f', 'o', 'o', -64, 5};//"foo."
             */
            ArrayList<Byte> b = new ArrayList<>();
            ArrayList<Byte> a = new ArrayList<>();

            //insert rest of bytes here
            Collections.addAll(a, (byte)1, (byte)'o', (byte)0,
                    (byte)0, (byte)5,
                    (byte)0, (byte)1,
                    (byte)0, (byte)0, (byte)0, (byte)0);

            serialize(name, b);

            a.add((byte)b.size());
            a.addAll(b);
            a.add((byte)0);

            byte[] buff = new byte[a.size()];
            for(int i=0;i<a.size();i++){
                buff[i] = a.get(i);
            }

            ByteArrayInputStream bstream = new ByteArrayInputStream(buff);
            ResourceRecord temp = null;
            try {
                temp = ResourceRecord.decode(bstream);
                assert(temp != null);
                assertEquals(((CName)temp).getCanonicalName(), name);
            } catch (ValidationException | IOException e) {
                assert(false);
                e.printStackTrace();
            }
        }

        private void serialize(String name, ArrayList<Byte> b) {
            for(int i=0;i<name.length();i++){
                if((name.charAt(i) == '.' && i != name.length()-1) || i == 0){
                    byte len = 0;
                    //find how long next segment is
                    for(int j=i+1;j<name.length();j++){
                        if(name.charAt(j) == '.'){
                            len = (byte)(j-i-1);
                            break;
                        }
                    }
                    if(i == 0 && name.length() != 1){
                        len++;
                    }
                    b.add(len);
                } else {
                    b.add((byte) name.charAt(i));
                }
            }
        }

        @Test
        @DisplayName("Test type 2")
        void decodeNS(){
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                            0, 2,
                            0, 1, //0x0001
                            0, 0, 0, 0,
                            6,
                            3, 'f', 'o', 'o', -64, 5};
            try {
                ResourceRecord temp = ResourceRecord.decode(new ByteArrayInputStream(buff));
                assert temp != null;
                assertEquals(temp.getClass(), NS.class);
            } catch (ValidationException | IOException e) {
                e.printStackTrace();
            }
        }

        @Test
        @DisplayName("Test type 5")
        void decodeCName(){
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                    0, 5,
                    0, 1, //0x0001
                    0, 0, 0, 0,
                    6,
                    3, 'f', 'o', 'o', -64, 5};
            try {
                ResourceRecord temp = ResourceRecord.decode(new ByteArrayInputStream(buff));
                assert(temp != null);
                assertEquals(temp.getClass(), CName.class);
            } catch (ValidationException | IOException e) {
                e.printStackTrace();
            }
        }

        @ParameterizedTest(name = "Valid ttl = ")
        @ValueSource(ints = {0, 1, 2147483647})
        void decodeTTL(int ttl){
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                    0, 2,
                    0, 1, //0x0001
                    (byte)((ttl >> 24) & 0xff), (byte)((ttl >> 16) & 0xff), (byte)((ttl >> 8) & 0xff), (byte)((ttl >> 0) & 0xff),
                    6,
                    3, 'f', 'o', 'o', -64, 5};

            try {
                ResourceRecord temp = ResourceRecord.decode(new ByteArrayInputStream(buff));
                assert(temp != null);
                assertEquals(temp.getTTL(), ttl);
            } catch (ValidationException | IOException e) {
                e.printStackTrace();
            }
        }
    }


    //Name setter and getter tests (DONE)
    //Name: -- these tests apply to all domain name field tests
    //  Each label must start with a letter, end with a letter or digit, and have as interior characters only letters
    //    (A-Z and a-z), digits (0-9), and hypen (-).
    //  A name with a single, empty label (".") is acceptable
    @Nested
    class NameSetterGetter {
        //set canonical name tests ERROR
        @ParameterizedTest(name = "Name error = {0}")
        @ValueSource(strings = {"", "asdf", "asdf.].", "asdf.Ƞ.", "asdf..", "www.baylor.edu/", "..", "asdf.asdf", "f0-9.c0m-.", "Ẵ.Ẓ.㛃.⭐.⭕.",
                "-a.f", "-.", "-",
                "a234567890123456789012345678901234567890123456789012345678901234.",
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a2345678901."//256
        })
        void setNameValidationException(String name) {
            ResourceRecord cn, ns;
            //CName
            try {
                cn = new CName(".", 0, ".");
                assertThrows(ValidationException.class, () -> cn.setName(name));
            } catch(Exception e){
                assert(false);
            }
            //NS
            try {
                ns = new NS(".", 0, ".");
                assertThrows(ValidationException.class, () -> ns.setName(name));
            } catch(Exception e){
                assert(false);
            }
        }
        @Test
        void setNameNullPtr() {
            ResourceRecord cn, ns;
            //CName
            try {
                cn = new CName(".", 0, ".");
                assertThrows(NullPointerException.class, () -> cn.setName(null));
            } catch(Exception e){
                assert(false);
            }
            //NS
            try {
                ns = new NS(".", 0, ".");
                assertThrows(NullPointerException.class, () -> ns.setName(null));
            } catch(Exception e){
                assert(false);
            }
        }

        //set canonical name tests VALID
        @ParameterizedTest(name = "Name valid = {0}")
        @ValueSource(strings = {"a23456789012345678901234567890123456789012345678901234567890123.",
                "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//122
                        "a23456789012345678901234567890123456789012345678901234567890.a23456789012345678901234567890123456789012345678901234567890." +//244
                        "a234567890.",//255
                "foo.", "foo.com.", "f0-9.c0m.", "google.com.", "www.baylor.edu.", "f0.c-0.", ".", "f-0.", "f-0a."
        })
        void setAndGetNameValid(String name) {
            ResourceRecord cn, ns;
            //CName
            try {
                cn = new CName(".", 0, ".");
                cn.setName(name);
                assertEquals(name, cn.getName());
            } catch(Exception e){
                assert(false);
            }
            //NS
            try {
                ns = new NS(".", 0, ".");
                ns.setName(name);
                assertEquals(name, ns.getName());
            } catch(Exception e){
                assert(false);
            }
        }
    }

    //TTL Setter and getter (DONE)
    @Nested
    class TTLSetterGetter {
        //ValidationException TTL tests
        @ParameterizedTest(name = "TTL error = {0}")
        @ValueSource(ints = {-1, -2147483648})
        void constTTLValidationError(int ttl){
            ResourceRecord cn, ns;
            //CName
            try {
                cn = new CName(".", 0, ".");
                assertThrows(ValidationException.class, () -> cn.setTTL(ttl));
            } catch(Exception e){
                assert(false);
            }
            //NS
            try {
                ns = new NS(".", 0, ".");
                assertThrows(ValidationException.class, () -> ns.setTTL(ttl));
            } catch(Exception e){
                assert(false);
            }
        }

        //set AND get ttl tests VALID
        @ParameterizedTest(name = "TTL valid = {0}")
        @ValueSource(ints = {0, 1, 2147483647})
        void setAndGetTTLValid(int ttl) {
            ResourceRecord cn, ns;
            //CName
            try {
                cn = new CName(".", 0, ".");
                cn.setTTL(ttl);
                assertEquals(ttl, cn.getTTL());
            } catch(Exception e){
                assert(false);
            }
            //NS
            try {
                ns = new NS(".", 0, ".");
                ns.setTTL(ttl);
                assertEquals(ttl, ns.getTTL());
            } catch(Exception e){
                assert(false);
            }
        }
    }
}