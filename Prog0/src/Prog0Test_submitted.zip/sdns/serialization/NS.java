package sdns.serialization;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Represents a NS and provides serialization/deserialization
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.1
 */
public class NS extends ResourceRecord {
    protected static final long NS_TYPE_VALUE = 2L;
    private String nameServer;

    /**
     * Constructs NS using given values
     * @param name RR name
     * @param ttl RR TTL
     * @param nameServer name server
     * @throws ValidationException if validation fails (see specification), including null name or nameServer
     */
    public NS(String name, int ttl, String nameServer) throws ValidationException {}

    /**
     * Get name server
     * @return name
     */
    public String getNameServer() { return this.nameServer; }

    /**
     * Set name server
     * @param nameServer new name server
     * @return this NS with new name server
     * @throws ValidationException if invalid name server, including null
     */
    public NS setNameServer(String nameServer) throws ValidationException { return null; }

    /**
     * Returns a String representation
     * NS: name=<name> ttl=<ttl> nameserver=<nameserver>
     *   For example
     *     NS: name=foo.com. ttl=500 nameserver=ns.com
     * @return a String representation
     */
    @Override
    public String toString() { return null; }

    @Override
    public void encode(OutputStream out) throws IOException { }

    @Override
    public long getTypeValue() {
        return NS_TYPE_VALUE;
    }
}
