package sdns.serialization;

import java.io.IOException;
import java.io.OutputStream;

/**
 * Represents a CName and provides serialization/deserialization
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.1
 */
public class CName extends ResourceRecord {
    private final long CN_TYPE_VALUE = 5L;

    private String canonicalName;

    /**
     * Constructs CName using given values
     * @param name RR name
     * @param ttl RR TTL
     * @param canonicalName Canonical name
     * @throws ValidationException if validation fails (see specification), including null name or canonical name
     */
    public CName(String name, int ttl, String canonicalName) throws ValidationException { }

    /**
     * Get canonical name
     * @return name
     */
    public String getCanonicalName() { return this.canonicalName; }

    /**
     * Set canonical name
     * @param canonicalName new canonical name
     * @return this RR with new canonical name
     * @throws ValidationException if invalid canonical name, including null
     */
    public CName setCanonicalName(String canonicalName) throws ValidationException { return null; }

    /**
     * Returns a String representation
     * CName: name=<name> ttl=<ttl> canonicalname=<canonicalname>
     *   For example
     *     CName: name=foo.com. ttl=500 canonicalname=ns.com
     *
     * @return String representation
     */
    @Override
    public String toString() { return null; }

    @Override
    public void encode(OutputStream out) throws IOException {}

    @Override
    public long getTypeValue() {
        return CN_TYPE_VALUE;
    }
}
