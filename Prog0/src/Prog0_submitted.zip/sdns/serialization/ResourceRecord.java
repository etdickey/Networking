package sdns.serialization;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Objects;

/**
 * Represents generic SDNS RR and provides serialization/deserialization You may make concrete anything listed as
 * abstract in this interface. In other words, abstract is not part of the requirement
 * (while the class, method, and parameters are required).
 *   Credit: Dr. Donahoo of Baylor University for comments and API
 * @version 1.0
 */
public abstract class ResourceRecord {
    protected static final long CN_TYPE_VALUE = 5L;
    protected static final long NS_TYPE_VALUE = 2L;
    protected static final int DOMAIN_NAME_MAX_LEN = 255;
    protected static final int DOMAIN_NAME_LABEL_MAX_LEN = 63;

    private String name = null;
    private int ttl = -1;

    protected static boolean isAZaz(char c){
        //I use the -1/+1 syntax because <= makes the assembly check 2 conditions whereas incrementing/decrementing allows
        //  for a faster check (because the +-1 is calculated at compile time)
        return ('A'-1 < c && c < 'Z'+1) || ('a'-1 < c && c < 'z'+1);
    }

    protected static boolean isAZaz09(char c){
        //I use the -1/+1 syntax because <= makes the assembly check 2 conditions whereas incrementing/decrementing allows
        //  for a faster check (because the +-1 is calculated at compile time)
        return ('0'-1 < c && c < '9'+1) || ('A'-1 < c && c < 'Z'+1) || ('a'-1 < c && c < 'z'+1);
    }

    protected static boolean isAZaz09Dash(char c){
        //I use the -1/+1 syntax because <= makes the assembly check 2 conditions whereas incrementing/decrementing allows
        //  for a faster check (because the +-1 is calculated at compile time)
        return ('0'-1 < c && c < '9'+1) || ('A'-1 < c && c < 'Z'+1) || ('a'-1 < c && c < 'z'+1) || (c == '-');
    }

    /**
     * Serializes the given domain name.  First checks that the name is a valid domain name though...
     * @param name the domain name to validate
     * @param b the byte arraylist to append to
     */
    protected void serializeDomainName(String name, ArrayList<Byte> b) throws ValidationException {
        if(!this.validateDomainName(name)){
            throw new ValidationException("ERROR: name provided to internal serialize function not a valid domain name", name);
        }

        if(name.length() == 1){
            b.add((byte)0);
            return;
        }

        for(int i=0;i<name.length();i++){
            if((name.charAt(i) == '.' && i != name.length()-1) || i == 0){
                byte len = 0;
                //find how long next segment is
                for(int j=i+1;j<name.length();j++){
                    if(name.charAt(j) == '.'){
                        len = (byte)(j-i-1);
                        break;
                    }
                }
                if(i == 0 && name.length() != 1){
                    len++;
                }
                b.add(len);
                if(i == 0){//insert the first letter
                    b.add((byte) name.charAt(0));
                }
            } else {
                if(i != name.length()-1){
                    b.add((byte) name.charAt(i));
                }
            }
        }

        //Add the final '0' to signal the end of the array
        b.add((byte)0);
    }

    /**
     * Validates a domain with the following constraints
     * @param domainName the domain name to validate
     * @return whether or not the domain name is valid based on the Specifications
     */
    protected static boolean validateDomainName(String domainName){
        Objects.requireNonNull(domainName, "Domain names cannot be null");

        //Name: -- this applies to all domain name fields
        //  Each label must start with a letter, end with a letter or digit, and have as interior characters only letters
        //    (A-Z and a-z), digits (0-9), and hypen (-).
        //  A name with a single, empty label (".") is acceptable

        //Base checks
        //A name may not be longer than 255 characters, inclusive of dots
        if(domainName.equals("") || domainName.length() < 1 || domainName.length() > DOMAIN_NAME_MAX_LEN){
            return false;
        }

        //  A name with a single, empty label (".") is acceptable
        if(domainName.equals(".")){
            return true;
        }

        //Check that the first character isn't an empty label so that when we split, it doesn't get rid of
        // that bad test case
        //Also check that the last character is a ., which gets lost when splitting
        if(domainName.charAt(0) == '.' || domainName.charAt(domainName.length()-1) != '.'){
            return false;
        }
        //Remove the last dot after validating that it's there because it causes split to add one extra field
        domainName = domainName.substring(0, domainName.length()-1);

        //Parse into labels
        String[] labels = domainName.split("\\.", -1);

        if(labels.length < 1){
            return false;
        }

        for(String l : labels){
            //A label may not be longer than 63 characters
            if(l.length() < 1 || l.length() > DOMAIN_NAME_LABEL_MAX_LEN){
                return false;
            }

            //  Each label must start with a letter
            if(!isAZaz(l.charAt(0))){
                return false;
            }

            //  Each label must end with a letter or digit
            if(!isAZaz09(l.charAt(l.length()-1))){
                return false;
            }

            //  Each label must have as interior characters only letters (A-Z and a-z), digits (0-9), and hypen (-)
            for(char c : l.toCharArray()){
                if(!isAZaz09Dash(c)){
                    return false;
                }
            }
        }

        return true;
    }

    private static boolean checkEndOfLabelsBitsSet(byte b){
        return (byte)(b & 0xC0) == (byte)(-64);
    }

    /**
     * Alias for readDomainName(in, -1) <-sentinal value
     * @param in the InputStream to read from
     * @return a string representing the deserialized domain name read
     * @throws ValidationException if parse or validation problem
     * @throws IOException if I/O problem
     */
    private static String readDomainName(InputStream in) throws ValidationException, IOException {
        return readDomainName(in, -1);
    }

    /**
     *
     * @param in the InputStream to read from
     * @param maxSize if the number of bytes read doesn't match the maxSize, a ValidationException is thrown
     * @return a string representing the deserialized domain name read
     * @throws ValidationException if parse or validation problem
     * @throws IOException if I/O problem
     */
    private static String readDomainName(InputStream in, int maxSize) throws ValidationException, IOException {
        Objects.requireNonNull(in, "Input stream cannot be null");

        int numBytes = 0;
        byte llen;
        char ch;
        StringBuilder dname = new StringBuilder();
        String finalString = "";

        //Check if maxSize is 0, in which case throw a validation exception
        if(maxSize == 0){
            throw new ValidationException("ERROR: Max size of a domain name cannot be 0", maxSize + "");
        }

        //read the first length
        llen = (byte) in.read();//discards the top 3 bytes, might output a negative
        numBytes++;

        //read the label length, label values, repeat until you read the end
        while(llen > 0 && !checkEndOfLabelsBitsSet(llen)){//0 is end of labels, -1 is end of stream
            for(int i=0; i<llen; i++){
                //read a character
                ch = (char)((byte) in.read());
                numBytes++;
                dname.append(ch);
            }
            dname.append('.');

            if(dname.length()-1 > DOMAIN_NAME_LABEL_MAX_LEN+1){//-1 for the '.'
                throw new ValidationException("Label cannot exceed " + DOMAIN_NAME_LABEL_MAX_LEN + " characters (including .)", dname.length() + "");
            }

            //spew into the output buffer
            finalString += dname.toString();
            dname.setLength(0);

            llen = (byte) in.read();
            numBytes++;
        }

        if(llen < -1){
            throw new ValidationException("ERROR: label length < 0", llen + "");
        } else if(llen == -1){
            throw new IOException("ERROR: End of input stream");
        }

        if(checkEndOfLabelsBitsSet(llen)){//clear the next byte too, according to the specifications
            in.read();
            numBytes++;
        }

        //Check for max size violations
        if(maxSize > 0 && maxSize != numBytes){
            throw new ValidationException("ERROR: RDLENGTH does not match RDATA length (rdlen=" + maxSize
                    + ", rdata.length()=" + numBytes, maxSize + "");
        }

        if(numBytes == 1){//then we have the '.' case
            finalString += '.';
        }

        return finalString;
    }

    private static int readIntBigEndian(InputStream in) throws IOException {
        int toReturn = 0;
        byte temp;

        for(int i=0;i<4;i++){
            toReturn = toReturn << 8;
            temp = (byte) in.read();
            toReturn |= (temp & 0x000F);
        }

        return toReturn;
    }

    private static int readUnsignedShortBigEndian(InputStream in) throws IOException {
        int toReturn = 0;
        byte temp;

        for(int i=0;i<2;i++){
            toReturn = toReturn << 8;
            temp = (byte) in.read();
            toReturn |= (temp & 0x00FF);
        }

        return toReturn;
    }

    /**
     * Deserializes message from input source
     * @param in deserialization input source
     * @return a specific RR resulting from deserialization
     * @throws ValidationException if parse or validation problem
     * @throws IOException if I/O problem (e.g., premature EoS)
     * @throws NullPointerException if in is null
     */
    public static ResourceRecord decode(InputStream in) throws ValidationException, IOException {
        Objects.requireNonNull(in, "Input stream cannot be null");

        //don't have to do any validation because it's done in all of the subclasses -- is this ok to do?
        //name
        String name = readDomainName(in);
        //Type
        byte temp, type;
        temp = (byte) in.read();
        type = (byte) in.read();

        //validate
        if(temp != 0){
            throw new ValidationException("ERROR: type bytes not set correctly: [" + temp + " " + type + "]", temp + "");
        }
        if(type != CN_TYPE_VALUE && type != NS_TYPE_VALUE){
            throw new ValidationException("ERROR: invalid type", type + "");
        }

        //0x0001
        temp = (byte) in.read();
        if(temp != 0){
            throw new ValidationException("ERROR: 0x0001 first byte not set correctly", temp + "");
        }
        temp = (byte) in.read();
        if(temp != 1){
            throw new ValidationException("ERROR: 0x0001 second byte not set correctly", temp + "");
        }

        //TTL
        int ttl = readIntBigEndian(in);

        //RDLength
        int rdlen = readUnsignedShortBigEndian(in);

        //RData
        String rdata = readDomainName(in, rdlen);

        //Build the object (which checks all of the fields
        ResourceRecord toReturn;
        //can't switch on a long apparently
        if(type == CN_TYPE_VALUE){
            toReturn = new CName(name, ttl, rdata);
        } else if(type == NS_TYPE_VALUE){
            toReturn = new NS(name, ttl, rdata);
        } else {
            throw new ValidationException("ERROR: INTERNAL ERROR, PLEASE REPORT.  Type=" + type, type + "");
        }

        return toReturn;
    }

    /**
     * Serializes RR to given sink
     * @param out serialization sink
     * @throws IOException if I/O problem
     * @throws NullPointerException if out is null
     */
    public void encode(OutputStream out) throws IOException {
        Objects.requireNonNull(out, "Output stream cannot be null");

        /*
            //foo. = 3 102, 111, 111, 192, 5 //-64 signed = 192 unsigned
            Valid data:
            byte[] buff = { 3, 'f', 'o', 'o', -64, 5,
                                0, 2,
                                0, 1, //0x0001
                                0, 0, 0, 0,
                                6,
                                3, 'f', 'o', 'o', -64, 5};//"foo."
         */
        //Construct the output
        ArrayList<Byte> a = new ArrayList<>();

        //Name
        try{
            this.serializeDomainName(this.getName(), a);
        } catch(ValidationException e){
            //Do nothing
//            throw new ValidationException("WARN WARN WARN: \"NAME\" FIELD DOES NOT CONTAIN A VALID DOMAIN NAME", this.getName());
        }

        //Type -- this is not expandable, and is written acknowledging the "quick and dirty" way was used.
        Collections.addAll(a, (byte)0, (byte)this.getTypeValue());

        //0x0001
        Collections.addAll(a, (byte)0, (byte)1);

        //TTL
        ByteBuffer buff = ByteBuffer.allocate(4);
        buff.order(ByteOrder.BIG_ENDIAN);
        buff.putInt(this.getTTL());
        Collections.addAll(a, buff.get(0), buff.get(1), buff.get(2), buff.get(3));

        //RData and RDLength
        ArrayList<Byte> rdataBytes = this.serializeRData();
        short rdlen = (short) rdataBytes.size();

        ByteBuffer buff2 = ByteBuffer.allocate(4);
        buff2.order(ByteOrder.BIG_ENDIAN);
        buff2.putShort(rdlen);

        //RDLength
        Collections.addAll(a, buff2.get(0), buff2.get(1));
        //RData
        a.addAll(rdataBytes);

        byte[] finalBuff = new byte[a.size()];
        for(int i=0;i<a.size();i++){
            finalBuff[i] = a.get(i);
        }
        out.write(finalBuff);
    }

    /**
     * Return type value for specific RR
     * @return type value
     */
    public abstract long getTypeValue();

    /**
     * Get name of RR
     * @return name
     */
    public String getName() { return this.name; }

    /**
     * Set name of RR
     * @param name new name of RR
     * @return this RR with new name
     * @throws ValidationException if new name invalid or null
     */
    public ResourceRecord setName(String name) throws ValidationException {
        try {
            Objects.requireNonNull(name, "Name cannot be null");
        } catch(NullPointerException n){
            throw new ValidationException(n.getMessage(), name);
        }

        //require non null and validate domain name all in one!
        if(this.validateDomainName(name)){
            this.name = name;
        } else {
            throw new ValidationException("Name did not pass domain name checks", name);
        }

        return this;
    }

    /**
     * Get TTL of RR
     * @return TTL
     */
    public int getTTL(){ return this.ttl; }

    /**
     * Set TTL of RR
     * @param ttl new TTL
     * @return this RR with new TTL
     * @throws ValidationException if new TTL invalid
     */
    public ResourceRecord setTTL(int ttl) throws ValidationException {
        if(ttl < 0){
            throw new ValidationException("TTL < 0", ttl + "");
        }
        this.ttl = ttl;
        return this;
    }

    /**
     * Returns a byte array of the rdata for this object.  For internal use only.
     * @return the serialized version of this objects rdata
     */
    protected abstract ArrayList<Byte> serializeRData();
}
