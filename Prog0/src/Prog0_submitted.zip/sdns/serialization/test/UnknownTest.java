package sdns.serialization.test;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import sdns.serialization.Unknown;
import sdns.serialization.ValidationException;

import static org.junit.jupiter.api.Assertions.*;

//Note: rerun all tests with different character encodings (UTF-32, UTF-16, etc) at runtime
/**
 * @author Ethan
 * @author Harrison
 */
class UnknownTest {
    private final long CN_TYPE_VALUE = 5L, NS_TYPE_VALUE = 2L;

    //Test that it always throws an exception no matter what (varied input) (DONE)
    @Nested
    class EncodeFails {
        @Test
        @DisplayName("Default encode fail")
        void test0() {
            Unknown ut = new Unknown();
            assertThrows(UnsupportedOperationException.class, () -> ut.encode(System.out));
        }

        @Test
        @DisplayName("Test 1 encode fail")
        void test1() {
            Unknown ut = new Unknown();
            try {
                ut.setName(".");
                ut.setTTL(0);
            } catch(Exception e){
                assert(false);
            }
            assertThrows(UnsupportedOperationException.class, () -> ut.encode(System.out));
        }
    }


    //Test that it doesn't equal either of the two known values (DONE)
    @Test
    void getTypeValue() {
        Unknown un = new Unknown();
        try {
            assertNotEquals(CN_TYPE_VALUE, un.getTypeValue());
            assertNotEquals(NS_TYPE_VALUE, un.getTypeValue());
        } catch(Exception e){
            assert(false);
        }
    }


    @Test
    void testToString() {
        String expected = "Unknown: name=foo.com. ttl=500";
        try {
            Unknown test = new Unknown();
            test.setName("foo.com.");
            test.setTTL(500);
            String output = test.toString();

            assertEquals(expected, output);
        } catch (ValidationException e) {
            fail();
        }
    }
}