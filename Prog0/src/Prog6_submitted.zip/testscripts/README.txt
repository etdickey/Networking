**These scripts were built to run on Windows**

Currently the only tests implemented are for the UDP client,
but similar tests have been run manually on the TCP clients as well.

1. Run clientTests/startServer.bat
- This should start the sdns/app/udp/client/test/TestUDPEchoServer.java
2. Run clientTests/basicTest.bat
3. Run clientTests/badServerTests.bat


These should say what the output should be when they run, allowing for manual verification of the UDP client.